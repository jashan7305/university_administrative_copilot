# Natural Language Processing and Large Language Models
*DRAFT for the Board of Studies: requires faculty review before adoption*

Programmes: AI, COMP, CSE-DS, DS, EXTC, IT | Academic year: 2026-27 | L-P-T: 2-2-0 | Credits: 3

**Prerequisites:** Data Structures and Algorithms, Python Programming, Applications of Machine Learning, Deep Learning, Advanced Techniques in Machine Learning

**Objectives:** To give students one coherent course on natural language processing and large language models that removes the overlap between 5 existing syllabi and adds the skills that the job descriptions ask for.

**Hours:** The units add up to 62 hours, while the current teaching scheme gives 30 lecture hours per semester: the committee should trim units or split the course in two.

## Units
1. **Introduction to Natural Language Processing** (2 h; shared topic (deduplicated)) — Introduction to Natural Language Processing NLP in real world, NLP tasks and applications, building blocks of language, various stages or levels of linguistic analysis in NLP, approaches to NLP, concept of Natural Language Understanding(NLU) and Natural Language Generation(NLG), Generic NLP pipeline, challenges in NLP
   *Source: Natural Language Processing (nm26b2f85a); Natural Language Processing (nm57ee6fd1); Natural Language Processing (nmd6d35385); Speech and Natural Language Processing (nm85e9140a)*
2. **Semantic Analysis and Vector Space Models** (7 h; shared topic (deduplicated)) — Semantic Analysis and Vector Space Models Semantic Analysis-Relations among lexemes & their senses –Homonymy, Polysemy, Synonymy, Hyponymy, WordNet, WordNet Hierarchy, concept of Word Sense Disambiguation (WSD) ,approaches to WSD, Vector Space Model- Distributional Semantics, Lexical Semantics, Vector Semantics, word embedding, word2vec, Glove
   *Source: Natural Language Processing (nm26b2f85a); Natural Language Processing (nm57ee6fd1); Natural Language Processing (nmd6d35385); Speech and Natural Language Processing (nm85e9140a)*
3. **Text Pre-processing and Text Representation** (5 h; shared topic (deduplicated)) — Text Pre-processing and Text Representation Basic text preprocessing-Tokenization, lower casing, stopword and punctuation removal, stemming, lemmatization Text representation (Feature Engineering) Basic vectorization approaches-label encoding, one hot encoding, Bag of Words (BoW), Term Frequency and Inverse Term Frequency (TF-IDF), Lexical similarity measures
   *Source: Natural Language Processing (nm26b2f85a); Natural Language Processing (nm57ee6fd1); Natural Language Processing (nmd6d35385); Speech and Natural Language Processing (nm85e9140a)*
4. **Pragmatic and Discourse Analysis** (4 h; shared topic (deduplicated)) — Pragmatic and Discourse Analysis Reference resolution, co reference resolution, pronoun resolution, approaches to pronoun resolution
   *Source: Natural Language Processing (nm26b2f85a); Natural Language Processing (nm57ee6fd1); Natural Language Processing (nmd6d35385)*
5. **Large Language Models (LLM)** (8 h; shared topic (deduplicated)) — Large Language Models (LLM) Introduction to LLM: difference between traditional language models and LLM, Auto regressive models, Overview of attention mechanisms, multi-head attention, and self-attention in transformer-based models. Positional Embeddings (PE): Importance of long sequences, drawbacks of sinusoidal PEs, Rotary based PE (RoPE). Encoder-only model: BERT (bidirectional Encoder Representation Transformer) architecture, Decoder-only model - Architecture of GPT (Generative Pretrained Transformer), Encoder-Decoder model - BART. LLM Frameworks: Langchain, LLaMA Index.
   *Source: Generative AI (nm8b216b85); Speech and Natural Language Processing (nm85e9140a)*
6. **Basic Text Processing** (6 h; existing unit, demanded by industry) — Basic Text Processing Tokenization, Stemming, Introduction, Machine Learning and NLP, Practice with ipython Notebooks, NLTK Text; Adopt a text collection, Tokenize Your Text Collection, Create a First Look at Your Text Collection, Study different types of Stemming rules
   *Source: Speech and Natural Language Processing (nm85e9140a); JD2; JD4; JD5*
7. **RAG and Fine Tuning** (6 h; existing unit, demanded by industry) — RAG and Fine Tuning Vector Databases, High-dimensional Data Storage, Vector Embeddings, High- Dimensional Semantic Similarity, Retrieval-Augmented Generation (RAG), Hyperparameter Tuning and Optimization, Full fine Tuning v/s Parameter Efficient Fine Tuning (PEFT) Techniques, LoRA, QLoRA
   *Source: Generative AI (nm8b216b85); JD1; JD4*
8. **Recall and ranking metrics** (6 h; new unit from job descriptions) — Topics: automatic metrics; recall and ranking metrics. Industry requirements: Evaluate fine-tuned models with automatic metrics and human evaluation, and track hallucination rates. Index documents in vector databases and evaluate retrieval with recall and ranking metrics.
   *Source: JD1; JD3*
9. **Human evaluation** (6 h; new unit from job descriptions) — Topics: evaluation; human evaluation. Industry requirements: Evaluate fine-tuned models with automatic metrics and human evaluation, and track hallucination rates. Knowledge of information retrieval, BM25 and evaluation of search systems.
   *Source: JD1; JD3*
10. **Prompt engineering** (6 h; new unit from job descriptions) — Topics: prompt engineering; prompts. Industry requirements: Experience with prompt engineering and few-shot prompting as a baseline before fine-tuning. Design prompts and guardrails that keep generated answers grounded in retrieved sources.
   *Source: JD1; JD3*
11. **Bias** (6 h; new unit from job descriptions) — Topics: bias. Industry requirements: Evaluate models for factual accuracy, bias and safety before release. Monitor deployed models for drift, toxicity and bias, and maintain guardrails.
   *Source: JD2; JD5*

## Learning outcomes
- Describe the fundamental concepts and techniques of natural language processing (Understand; source nmd6d35385)
- Apply text preprocessing, word level analysis and syntax level analysis techniques on textual data (Apply; source nmd6d35385)
- Implement approaches for semantic level analysis and pragmatic level analysis (Apply; source nmd6d35385)
- Illustrate various real world applications of NLP (Understand; source nmd6d35385)
- Explain and apply techniques for recall and ranking metrics in a lab exercise (Understand; source JD1, JD3)
- Explain and apply techniques for human evaluation in a lab exercise (Understand; source JD1, JD3)
- Explain and apply techniques for prompt engineering in a lab exercise (Understand; source JD1, JD3)
- Explain and apply techniques for bias in a lab exercise (Understand; source JD2, JD5)

## Lab work
- Hands-on exercise: Basic Text Processing
- Hands-on exercise: RAG and Fine Tuning
- Hands-on exercise: Recall and ranking metrics
- Hands-on exercise: Human evaluation
- Hands-on exercise: Prompt engineering
- Hands-on exercise: Bias
- Lab environment: cloud GPUs, Python, PyTorch and REST API development

**Assessment:** As per the programme's internal continuous assessment and term-end examination norms (not part of the parsed syllabi).

## Courses this syllabus replaces
- Natural Language Processing (AI, 2026-27, nmd6d35385)
- Natural Language Processing (COMP, CSE-DS, IT, 2026-27, nm57ee6fd1)
- Natural Language Processing (EXTC, 2024-25, nm26b2f85a)
- Speech and Natural Language Processing (DS, 2026-27, nm85e9140a)
- Generative AI (AI, 2026-27, nm8b216b85)