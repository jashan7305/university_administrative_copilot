Group 10 - week3 code. Full runnable project: github.com/jashan7305/university_administrative_copilot
Setup: uv sync; run commands are listed in the repository README.
